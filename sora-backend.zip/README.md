# Sora Backend (simple)

This is a minimal Node.js/Express backend that forwards text to the **Sora** API.
It expects the Sora API key to be available as an environment variable named `SORA_API_KEY`.

## Files
- `index.js` — Express server with a POST `/generate` endpoint (body: `{ "text": "..." }`)
- `package.json` — npm metadata and start script

## How to deploy on Render.com (recommended)
1. Create a new **Web Service** on Render and connect to this repository.
2. Set **Environment** to `Node` and **Branch** to `main` (or the branch you use).
3. Set **Build Command**: `npm install`
4. Set **Start Command**: `npm start`
5. In Render dashboard, open **Environment** → **Environment Variables** and add:
   - `SORA_API_KEY` = your_sora_api_key_here
6. Deploy. The service will start and listen on the port assigned by Render (via `process.env.PORT`).

## Local testing
1. `npm install`
2. `export SORA_API_KEY="your_key_here"` (Windows: set in Powershell or CMD)
3. `npm start`
4. Send a POST request: `POST http://localhost:3000/generate` with JSON body `{ "text": "Hello" }`

## Replace Sora endpoint
Update the `soraEndpoint` variable inside `index.js` to the real Sora API endpoint and adjust the payload/headers if Sora expects a different shape.

## Notes
- Do **not** store API keys in your repository. Use Render environment variables (as above).
- Increase timeout if Sora generation takes longer.
