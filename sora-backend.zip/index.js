const express = require('express');
const axios = require('axios');
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

app.get('/', (req, res) => {
  res.send('Sora backend is running. Use POST /generate with JSON { "text": "..." }');
});

app.post('/generate', async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: 'Missing "text" in request body.' });

    const SORA_API_KEY = process.env.SORA_API_KEY;
    if (!SORA_API_KEY) return res.status(500).json({ error: 'SORA_API_KEY is not set in environment.' });

    const soraEndpoint = 'https://api.sora.example/v1/generate';

    const response = await axios.post(soraEndpoint, {
      prompt: text
    }, {
      headers: {
        'Authorization': `Bearer ${SORA_API_KEY}`,
        'Content-Type': 'application/json'
      },
      timeout: 120000
    });

    return res.json({ sora: response.data });
  } catch (err) {
    console.error('Error calling Sora API:', err && err.message ? err.message : err);
    if (err.response && err.response.data) {
      return res.status(502).json({ error: 'Sora API error', details: err.response.data });
    }
    return res.status(500).json({ error: 'Internal server error', details: err.message || err });
  }
});

app.listen(port, () => {
  console.log(`Sora backend listening on port ${port}`);
});
